//
//  ViewController.swift
//  cameraWithAlbumSwift
//
//  Created by cricket21 on 05/07/17.
//  Copyright © 2017 cricket21. All rights reserved.
//
import UIKit
import Photos
class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    var assetCollection: PHAssetCollection!
    var picker = UIImagePickerController()
    var albumName = NSString()
    
    @IBOutlet var myImageView: UIImageView!
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    albumName="MYCUSALBUM"
    if let assetCollection = fetchAssetCollectionForAlbum() {
    self.assetCollection = assetCollection
    return
    }
    if PHPhotoLibrary.authorizationStatus() != PHAuthorizationStatus.authorized {
    PHPhotoLibrary.requestAuthorization({ (status: PHAuthorizationStatus) -> Void in
    ()
    })
    }
            
    if PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.authorized {
    self.createAlbum()
    } else {
    PHPhotoLibrary.requestAuthorization(requestAuthorizationHandler)
    }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func captureAction(_ sender: Any) {
    picker.delegate = self
    picker.sourceType = UIImagePickerControllerSourceType.camera
    self.present(picker, animated: true, completion: nil)
    }
   
    func imagePickerController(_ picker: UIImagePickerController,didFinishPickingMediaWithInfo info: [String : Any]){
    let chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        // use the image
    myImageView.image=chosenImage
    save(image: chosenImage)
        dismiss(animated: true, completion: nil)
    }
    func save(image: UIImage) {
        if assetCollection == nil {
            return
        }
        PHPhotoLibrary.shared().performChanges({
            let assetChangeRequest = PHAssetChangeRequest.creationRequestForAsset(from: image)
            let assetPlaceHolder = assetChangeRequest.placeholderForCreatedAsset
            let albumChangeRequest = PHAssetCollectionChangeRequest(for: self.assetCollection)
            let enumeration: NSArray = [assetPlaceHolder!]
            albumChangeRequest!.addAssets(enumeration)
            
        }, completionHandler: nil)
    }
    func requestAuthorizationHandler(status: PHAuthorizationStatus) {
        if PHPhotoLibrary.authorizationStatus() == PHAuthorizationStatus.authorized {
            // ideally this ensures the creation of the photo album even if authorization wasn't prompted till after init was done
            print("trying again to create the album")
            self.createAlbum()
        } else {
            print("should really prompt the user to let them know it's failed")
        }
    }
    
    func createAlbum() {
        PHPhotoLibrary.shared().performChanges({
            PHAssetCollectionChangeRequest.creationRequestForAssetCollection(withTitle:self.albumName as String)
        // create an asset collection with the album name
        }) { success, error in
            if success {
                self.assetCollection = self.fetchAssetCollectionForAlbum()
            } else {
                print("error \(String(describing: error))")
            }
        }
    }
    
    func fetchAssetCollectionForAlbum() -> PHAssetCollection? {
        let fetchOptions = PHFetchOptions()
        fetchOptions.predicate = NSPredicate(format: "title = %@", albumName)
        let collection = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: fetchOptions)
        
        if let _: AnyObject = collection.firstObject {
            return collection.firstObject
        }
        return nil
    }
   }

